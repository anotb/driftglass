# Has Hormuz reopened enough for the gas market to normalize?

A sourced answer from Driftglass

<small class="illustrative-disclosure">Illustrative example · public sources</small>

As of: 2026-07-07T14:00:00.000Z

## Bottom line

No. Hormuz traffic is recovering, but LNG supply has not normalized. The bottleneck has moved from the Strait to damaged Qatari export capacity: replacement supply has contained most of the loss, while the Ras Laffan repair schedule sets a multi-year recovery clock.

### Why this is happening

- Replacement supply narrowed the gap: From March through June, Qatar and UAE loadings were about 35 bcm lower than a year earlier while production elsewhere rose about 27 bcm; global LNG output still fell 4%. Substitution prevented a deeper loss without restoring pre-shock supply. [[1]](https://www.iea.org/reports/gas-market-report-q3-2026/executive-summary)
- Damage outlasts reopening: Reopening cannot restore output from two damaged Ras Laffan trains that removed 17% of Qatar's export capacity. With repairs expected to take up to five years, plant capacity now sets part of the recovery clock. [[2]](https://www.eia.gov/todayinenergy/detail.php?id=67484)
- Asia's premium redirected flexible cargoes: Weaker demand and cargo diversion helped lower prices while supply stayed impaired. Asia's $2.1 per MBtu premium pulled flexible cargoes east, showing how prices can normalize before physical supply; the IEA still estimates 140 bcm of cumulative LNG losses through 2030. [[1]](https://www.iea.org/reports/gas-market-report-q3-2026/executive-summary)

### Alternative case

New non-Gulf capacity could normalize the wider market before Qatar repairs its damaged trains. The IEA expects close to 50 bcm from new projects and more than 10 bcm from existing producers; if the Strait fully reopens in Q3 and undamaged facilities return in Q4, global supply could hold flat in 2026 despite Qatar’s outage. [[1]](https://www.iea.org/reports/gas-market-report-q3-2026/executive-summary)

### Signals to watch

- Normalization test: carrier traffic and Qatar and UAE cargo loadings recover together for several weeks. [[1]](https://www.iea.org/reports/gas-market-report-q3-2026/executive-summary) [[3]](https://www.eia.gov/international/content/analysis/special_topics/World_Oil_Transit_Chokepoints/)
- Damaged liquefaction trains return to production and the IEA cuts its cumulative loss estimate. [[1]](https://www.iea.org/reports/gas-market-report-q3-2026/executive-summary) [[2]](https://www.eia.gov/todayinenergy/detail.php?id=67484)

## Sources

- [1] **International Energy Agency:** Gas Market Report, Q3-2026 _(Original source)_ — https://www.iea.org/reports/gas-market-report-q3-2026/executive-summary
- [2] **U.S. Energy Information Administration:** U.S. natural gas exports to grow nearly 30% by 2027 as LNG facilities ramp up _(Independent source)_ — https://www.eia.gov/todayinenergy/detail.php?id=67484
- [3] **U.S. Energy Information Administration:** World Oil Transit Chokepoints _(Related report)_ — https://www.eia.gov/international/content/analysis/special_topics/World_Oil_Transit_Chokepoints/

