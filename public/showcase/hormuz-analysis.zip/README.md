# Driftglass shared briefing

Open `index.html` to read this briefing locally, or publish the folder with any static host.

## Contents

- `index.html`: recipient-facing briefing
- `evidence.md`: readable source record
- `data.json`: structured recipient copy
- `driftglass-pack.json`: optional Driftglass follow-up setup

## Optional Cloudflare hosting

Open https://www.cloudflare.com/drop/ and upload this ZIP. Share the generated URL, or claim the deployment if you want to keep it. Cloudflare Drop is one hosting option; it is not required to read the briefing.
